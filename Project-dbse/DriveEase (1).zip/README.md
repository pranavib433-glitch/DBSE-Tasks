# DriveEase — Car Rentals and Mobility App

Frontend-only prototype for a self-service car rental and mobility application.

## Run
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. No backend or installation is required.

## Main flow
Home → Search Cars → Car Details → Booking → Payment → Confirmation → Self-Service

## Included screens
- Home
- Login / Register
- Car listing + filters
- Car details
- Booking
- Payment demo
- Booking confirmation
- Self-service vehicle pass
- My bookings
- Profile

## Technologies
HTML5, CSS3, JavaScript, localStorage.

This is a frontend prototype. Payment and vehicle unlocking are simulated and do not process real payments or control real vehicles.
